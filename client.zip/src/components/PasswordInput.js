import React, { useState } from "react";
import './input.sass';
import VisibilityToggle from "./VisibilityToggle";
import clsx from 'clsx';

function PasswordInput(props) {

    const [isVisible, setVisibility] = useState(props.isVisible || false);
    const [isValid, setValidity] = useState(false);

    function handleChange(e) {
        if (props.onChange)
            props.onChange(e.target.value);
        if (props.validate)
            setValidity(props.validate(e.target.value));
    }

    return(
        <div className="flex-row">
            <input 
                className={ clsx('text-input', props.validate && !isValid && 'error', ) } 
                type={ clsx(isVisible ? 'text' : 'password') } 
                onChange={ handleChange } 
                placeholder={ props.placeholder } 
            />
            <VisibilityToggle onToggle={ () => { setVisibility(!isVisible); } } isVisible={ isVisible }/>
        </div>
    );
}

export default PasswordInput;