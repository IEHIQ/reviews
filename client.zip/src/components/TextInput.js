import React, { useState } from "react";
import './input.sass';
import clsx from 'clsx';

function TextInput(props) {

    const [isValid, setValidity] = useState(props.isValid && true);

    function handleChange(e) {
        if (props.onChange)
            props.onChange(e.target.value);
        if (props.validate)
            setValidity(props.validate(e.target.value));
    }

    return(
        <div className="flex-stretch">
            <input 
                className={ clsx('text-input', props.validate && !isValid && 'error', ) }  
                type='text' 
                onChange={ handleChange } 
                placeholder={ props.placeholder } 
            />
        </div>
    );
}

export default TextInput;