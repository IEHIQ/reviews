import React, { useState } from 'react';
import PasswordInput from '../../../components/PasswordInput';
import TextInput from '../../../components/TextInput';

function Login(props) {

    const [login, setLogin] = useState(props.login && '');
    const [password, setPassword] = useState(props.password && '');
    const [isLoginValid, setLoginValidity] = useState(false);
    const [isPasswordValid, setPasswordValidity] = useState(false);

    function validateLogin(login) {
        let validity = /^\w{5,20}$/.test(login);
        // 5-20 lettres, numbers or _ symbols for login
        setLoginValidity(validity);
        return validity;
    }

    function validatePassword(password) {
        let validity = /^[\w.,!@#$%^&*]{8,32}$/.test(password)
        // 8-32 letters, numbers or special symbols for password
        setPasswordValidity(validity);
        return validity;
    }

    function handleSubmit(e) {
        console.log(`Логин: ${login}, Пароль: ${password}`);
        e.preventDefault();
    }

    return (
        <form className='card' onSubmit={ handleSubmit }>
            <label className='form-label l b'>Вход</label>
            <TextInput 
                validate={ validateLogin }
                placeholder='Логин'
                onChange={ (login) => { setLogin(login); } }
            />
            <PasswordInput 
                validate={ validatePassword }
                placeholder='Пароль'
                onChange={ (password) => { setPassword(password); } }
            />
            <input type="submit" className='form-button m b' disabled={ !isLoginValid || !isPasswordValid } value="Войти" />
        </form>
    );
}

export default Login;