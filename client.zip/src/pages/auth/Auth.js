import React from 'react';
import { Link, Outlet, Route, Routes } from 'react-router-dom';
import './auth.sass';
import Login from './login/Login';

function Chooser() {
    return (
        <div className='card'>
            <Link className='form-button register m b' to='register'>Зарегистрироваться</Link>
            <Link className='form-button login m b' to='login'>Войти</Link>
        </div>
    )
}

// class Login extends React.Component {
//     constructor(props) {
//         super(props);
//         this.state = {
//             login: '',
//             password: '', 
//             isLoginValid: false, 
//             isPasswordValid: false,
//             isPasswordVisible: false 
//         };
//         this.handleLoginChange = this.handleLoginChange.bind(this);
//         this.handlePasswordChange = this.handlePasswordChange.bind(this);
//         this.handlePasswordVisibility = this.handlePasswordVisibility.bind(this);
//         this.handleSubmit = this.handleSubmit.bind(this);
//     }

//     handleLoginChange(event) {
//         // 5-20 lettres, numbers or _ symbols for login
//         let valid = /^\w{5,20}$/.test(event.target.value) 
//         if (!valid) {
//             // incorrect popup
//             // console.log(`Incorrect login!`);
//         }
//         this.setState({ isLoginValid : valid });
//         this.setState({ login : event.target.value });
//     }

//     handlePasswordChange(event) {
//         // 8-32 letters, numbers or special symbols for password
//         let valid = /^[\w.,!@#$%^&*]{8,32}$/.test(event.target.value);
//         if (!valid) {
//             // incorrect popup
//             // console.log(`Incorrect password!`);
//         }
//         this.setState({ isPasswordValid : valid });
//         this.setState({ password : event.target.value });
//     }

//     handlePasswordVisibility(event) {
//         this.setState({ isPasswordVisible : event.target.value });
//     }

//     handleSubmit(event) {
//         console.log(`Логин: ${this.state.login}, Пароль: ${this.state.password}`);
//         event.preventDefault();
//     }

//     render() {
//         return (
//             <form className='card' onSubmit={this.handleSubmit}>
//                 <label className='form-label l b'>Вход</label>
//                 <input type='text' className={ `form-text m ${ !this.state.isLoginValid && 'error' }` } id='text-login' value={ this.state.login } placeholder='Логин' onChange={this.handleLoginChange} />
//                 <input type={this.state.isPasswordVisible ? 'text' : 'password' } className={ `form-text m ${ !this.state.isPasswordValid && 'error' }` } id='text-password' value={ this.state.password } placeholder='Пароль' onChange={this.handlePasswordChange} />
//                 <input type="submit" className='form-button m b' disabled={ !this.state.isLoginValid || !this.state.isPasswordValid } value="Войти" />
//             </form>
//         );
//     }
// }



function Auth(props) {
    return (
        <div className='page flex-container flex-center'>
            <Routes>
                <Route path='*' element = { <Chooser /> }/>
                <Route path='login' element = { <Login /> }/>
                {/* <Route path='register' element = { <Register /> }/> */}
            </Routes>

            <Outlet />
        </div>
    );
}

export default Auth;