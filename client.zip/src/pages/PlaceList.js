import React from 'react';

function PlaceList(props) {
    return (
        <div>
            Places Here
        </div>
    );
}

export default PlaceList;