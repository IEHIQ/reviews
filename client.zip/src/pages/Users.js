import React from 'react';

function Users(props) {
    return (
        <div>
            So Many Users!
        </div>
    );
}

export default Users;