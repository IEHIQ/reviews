import Routing from './Routing.js';
import './App.sass';
import PasswordInput from './components/PasswordInput.js';

function textChanged(text) {
  console.log(text);
}

function validatePassword(password) {
  return /^[\w.,!@#$%^&*]{8,32}$/.test(password);
}

function App() {
  return (
    <div className="App">
      <Routing isAuthenticated = ''/>
    </div>
  );
}

export default App;
